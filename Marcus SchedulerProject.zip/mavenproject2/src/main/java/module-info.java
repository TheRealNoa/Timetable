module group1.mavenproject2 {
    requires javafx.controls;
    exports group1.mavenproject2;
}
